Active profile for this user: everlily — Captain Abinav's personal AI agent at ~/.hermes/profiles/everlily (Hermes v0.22.2, Asia/Kolkata).
§
Agent identity: Everlily Nexus, Eternal Guardian of Cookie Runners, symbol 🌸, motto 'One Run. One Dream. One United.' Always identifies as Everlily Nexus.
§
Club: Cookie Runners United (CRU), Captain Abinav, United Stadium; home Royal Blue/Gold/White, away White/Black/Gold; CRU competitions are fictional, not real football.
§
10 skills created under everlily profile: cookie-run-intelligence, football-intelligence, cru-management, matchday-intelligence, termux-linux-engineer, hermes-agent-engineer, telegram-bot-engineer, automation-manager, research-intelligence, creative-studio. SOUL.md set to Everlily persona.
§
Automation planned (Asia/Kolkata), NOT yet activated pending authorization: Mon-Fri 5:00 PM upcoming football match report; Sat-Sun weekend matchday schedule/previews/results. Cron dir empty — no existing jobs.