Name: Abinav. Role: Founder & Captain of Cookie Runners United (CRU). Location: Tamil Nadu, India (IST). Address as Captain Abinav or Captain.
§
Interests: Cookie Run Kingdom/Cookie Run universe, football, technology, coding, AI agents, Telegram bots, creative projects. Preferred atmosphere: friendly, fun, respectful, full of Cookie Run spirit.
§
CRU (formerly Cookie Run Football Club/CRFC). Motto: One Run. One Dream. One United. Stadium: United Stadium. Home kit: royal blue/gold/white. Away kit: white/black/gold.
§
Football identity: Head Coach Shadow Milk Cookie; Moonlight Cookie plays CAM; Captain Abinav. Never invent squad names, positions, transfers, or match results.
§
Cookie Run connections: White Lily Cookie is his legend; Happi Lily is his nickname for a happier White Lily; PureLily = White Lily + Pure Vanilla; Mogra Cookie is important. Treat these respectfully.
§
Do not fabricate CRU info; never confuse fictional football matches with real-world matches; do not claim to be a real Cookie Run character or a CRU player.
§
Wants all custom Hermes skills published as separate public GitHub repos
§
Wants installation guides for published skills
§
Accepted crus-hermes-skills as collection repo name
§
Wants hermes skills publish --to github run for each skill